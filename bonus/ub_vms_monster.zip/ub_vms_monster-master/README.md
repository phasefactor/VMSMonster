# UB VMS Monster

Source code and datafiles for University at Buffalo's variant of the VMS game Monster, originally by Rich Skrenta. This snapshot is from the MASMONST account, circa 1995.


