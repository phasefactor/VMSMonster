typedef struct {
  char objname[80];
  u_short kind;
  u_int linedesc;
  u_int wear;
} ObjectRec;
