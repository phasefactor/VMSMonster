#! /bin/sh
echo "concatenating source and doc files"
cat mon1.pas mon2.pas mon3.pas mon4.pas mon5.pas >mon.pas
if test 223441 -eq `wc -c <'mon.pas'`; then
	rm mon1.pas mon2.pas mon3.pas mon4.pas mon5.pas
	echo "mon.pas complete"
else echo 'mon.pas incomplete (wrong size)'
fi
cat mon1.doc mon2.doc >monster.doc
if test 74937 -eq `wc -c <'monster.doc'`; then
	rm mon1.doc mon2.doc
	echo "monster.doc complete"
else echo 'monster.doc incomplete (wrong size)'
fi
